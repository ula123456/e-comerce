<?php
$db=new PDO('mysql:host=localhost;dbname=fotobank','root','root');
?>