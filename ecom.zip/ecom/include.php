<?php
require_once './routes/actions/functions/ip.php';

		include("./routes/actions/functions/conn/db.php");
		include("./routes/actions/functions/queryDB.php");
		
		
