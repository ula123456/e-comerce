<div id="footer"><!-- futer start -->
				<h2 style="text-align:center; padding-top:30px;">&copy; 2020-<?php echo date('Y'); ?>by www.metrix.com</h2>
		</div><!-- futer end -->
 

	</div><!-- end main container -->
</body>
</head>
</html>