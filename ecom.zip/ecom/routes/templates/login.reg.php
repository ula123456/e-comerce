<div class="register_login">
				<div class="login"><a href= '/ecom/index.php/login'>Login</a></div>
				
				                   
				&nbsp;&nbsp;
				<div class="register"><a href="/ecom/index.php/register">Register<a/></div>
			</div><!-- register login -->
			