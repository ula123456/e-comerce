<?php  include("templates/header.php");  
include("templates/sidebar.php"); ?>




 <?php include("templates/footer.php");  ?>