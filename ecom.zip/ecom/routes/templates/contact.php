<?php  include("routes/templates/header.php");  
include("routes/templates/sidebar.php"); ?>

contact

 <?php include("routes/templates/footer.php");  ?>