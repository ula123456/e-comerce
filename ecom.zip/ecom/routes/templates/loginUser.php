<div class="login_box">
<form method="post" action="">
	<table align="left" width="70%">
		<tr align="left">
			<td colspan="4">
				<h2>login</h2><br/>
				<span>
Don't have accaunt? <a href="register.php">Register Here</a><br/><br/>
				</span>
			</td>
		</tr>
		<tr>

		<td width="15%"><b>Email:</b> </td>
		<td colspan="3"><input type="text" name="email" required placeholder="email"></td>

		</tr>
		<tr>

		<td width="15%"><b>Password:</b> </td>
		<td colspan="3"><input type="password" name="password" required placeholder="Password"></td>

		</tr>
		<tr align="left">
		<td > </td>
						 	 		
		<td colspan="4">
		<a href="checkout.php?forgot_pass">
			Forgot Password</a> </td>
		</tr>
		<tr align="left">
		<td > </td>
					 	 		
		<td colspan="4"> <input type="submit" name="login" value="Login"></td>
		</tr>
	</table>
</form>
</div>