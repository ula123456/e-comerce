<?php 
include("routes/templates/header.php");
include("routes/templates/sidebar.php"); 
include("routes/templates/products.php"); 

include("routes/templates/footer.php");  ?>