<?php 
require_once 'routes/templates/register.php';
				require_once 'routes/register.php';